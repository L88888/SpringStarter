package com.sit.client.queue.handler;

//import com.lmax.disruptor.EventFactory;
//import com.sit.client.queue.event.TpcEvent;
//
///**
// * @program: spring-starter
// * @description:
// * @author: LIULEI-TGL
// * @create: 2021-08-31 16:31:
// **/
//public class TpcEventFactory implements EventFactory<TpcEvent> {
//
//    @Override
//    public TpcEvent newInstance() {
//        return new TpcEvent();
//    }
//}
