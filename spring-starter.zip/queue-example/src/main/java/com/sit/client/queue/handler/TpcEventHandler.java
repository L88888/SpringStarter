package com.sit.client.queue.handler;

//import com.lmax.disruptor.EventHandler;
//import com.sit.client.queue.event.TpcEvent;
//
///**
// * @program: spring-starter
// * @description:
// * @author: LIULEI-TGL
// * @create: 2021-08-31 16:34:
// **/
//public class TpcEventHandler implements EventHandler<TpcEvent> {
//    @Override
//    public void onEvent(TpcEvent tpcEvent, long l, boolean b) throws Exception {
//
//    }
//}
