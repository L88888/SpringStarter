package com.sit.client.queue.event;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Queues;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;


/**
 * @program: spring-starter
 * @description: 套牌车中间对象
 * @author: LIULEI-TGL
 * @create: 2021-08-31 16:32:
 **/
public class TpcEvent {


    /**
     * 模拟设备状态数据实时写入阻塞队列
     */
    LinkedBlockingDeque<Object> q = new LinkedBlockingDeque<Object>(50000);

    /**
     * 每隔一段时间获取一次队列中的数据
     */
    public void realGetData(){
        try {
            List temp = new ArrayList<>(1000);
            Queues.drain(q, temp, 1000, 5 * 1000, TimeUnit.SECONDS);
            // 消费队列设备状态数据开始入库pg库
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
