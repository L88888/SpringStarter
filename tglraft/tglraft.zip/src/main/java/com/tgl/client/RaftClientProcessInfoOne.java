package com.tgl.client;

/**
 * @program: spring-starter
 * @description: 客户端发送消息，接收消息返回值
 * @author: LIULEI-TGL
 * @create: 2021-06-08 18:57:
 **/
public class RaftClientProcessInfoOne {
}
